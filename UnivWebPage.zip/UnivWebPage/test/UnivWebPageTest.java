

import java.util.ArrayList;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author darac
 */
public class UnivWebPageTest {
    
    /**
     * default constuctor.
     */
    public UnivWebPageTest() {
    }
    

    /**
     * Test of getEnrollment method, of class UnivWebPage.
     */
    @Test
    public void testGetEnrollment() {
        System.out.println("getEnrollment");
        UnivWebPage a;

        a = new UnivWebPage("Appalachian State University",
            "http://appstate.edu", "2001/09/17", "2024/03/05");
        a.setYearFounded(1899);
        a.setType("Public");
        a.setEnrollment(20436);
        int expResult = 20436;
        assertEquals(expResult,a.getEnrollment());
    }

    /**
     * Test of setType method, of class UnivWebPage.
     */
    @Test
    public void testSetType() {
        System.out.println("setType");
        UnivWebPage a;
        ArrayList<UnivWebPage> list = new ArrayList<UnivWebPage>();

        a = new UnivWebPage("Appalachian State University",
            "http://appstate.edu", "2001/09/17", "2024/03/05");
        a.setYearFounded(1899);
        a.setType("Public");
        a.setEnrollment(20436);
        assertEquals("Public",a.getType());
    }

    /**
     * Test of getType method, of class UnivWebPage.
     */
    @Test
    public void testGetType() {
        System.out.println("getType");
        UnivWebPage a;
        ArrayList<UnivWebPage> list = new ArrayList<UnivWebPage>();

        a = new UnivWebPage("Appalachian State University",
            "http://appstate.edu", "2001/09/17", "2024/03/05");
        a.setYearFounded(1899);
        a.setType("Public");
        a.setEnrollment(20436);
        assertEquals("Public", a.getType());
    }

    /**
     * Test of setEnrollment method, of class UnivWebPage.
     */
    @Test
    public void testSetEnrollment() {
        System.out.println("setEnrollment");
        UnivWebPage a;
        ArrayList<UnivWebPage> list = new ArrayList<UnivWebPage>();
        a = new UnivWebPage("Appalachian State University",
            "http://appstate.edu", "2001/09/17", "2024/03/05");
        a.setYearFounded(1899);
        a.setType("Public");
        a.setEnrollment(20436);
        assertEquals(20436, a.getEnrollment());
    }

    /**
     * Test of getYearFounded method, of class UnivWebPage.
     */
    @Test
    public void testGetYearFounded() {
        System.out.println("GetYearFounded");
        UnivWebPage a;
        ArrayList<UnivWebPage> list = new ArrayList<UnivWebPage>();
        a = new UnivWebPage("Appalachian State University",
            "http://appstate.edu", "2001/09/17", "2024/03/05");
        a.setYearFounded(1899);
        a.setType("Public");
        a.setEnrollment(20436);
        assertEquals(1899, a.getYearFounded());
    }
    /**
     * Test of setYearFounded method, of class UnivWebPage.
     */
    @Test
    public void testSetYearFounded() {
        System.out.println("setYearFounded");
        UnivWebPage a;
        ArrayList<UnivWebPage> list = new ArrayList<UnivWebPage>();
        a = new UnivWebPage("Appalachian State University",
            "http://appstate.edu", "2001/09/17", "2024/03/05");
        a.setYearFounded(1899);
        a.setType("Public");
        a.setEnrollment(20436);
        assertEquals(1899, a.getYearFounded());
        
    }
    
}
