

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author darac
 */
public class WebPageTest {
    /**
     * default constructor.
     */
    public WebPageTest() {
    }
    

    /**
     * Test of getTitle method, of class WebPage.
     */
    @Test
    public void testGetTitle() {
        System.out.println("getTitle");
        WebPage instance = new WebPage("Wake Forest University","http://www.wfu.edu",
                "1991/04/23", "2024/03/05");
        String expResult = "Wake Forest University";
        String result = instance.getTitle();
        assertEquals(expResult, result);
    }

    /**
     * Test of getURL method, of class WebPage.
     */
    @Test
    public void testGetURL() {
        System.out.println("getURL");
        WebPage instance = new WebPage("Wake Forest University","http://www.wfu.edu", 
                "1991/04/23", "2024/03/05");
        String expResult = "http://www.wfu.edu";
        String result = instance.getURL();
        assertEquals(expResult, result);
    }

    /**
     * Test of getCreateDate method, of class WebPage.
     */
    @Test
    public void testGetCreateDate() {
        System.out.println("getCreateDate");
        WebPage instance =new WebPage("Wake Forest University","http://www.wfu.edu", 
                "1991/04/23", "2024/03/05");
        String expResult = "1991/04/23";
        String result = instance.getCreateDate();
        assertEquals(expResult, result);
    }

    /**
     * Test of getVisitDate method, of class WebPage.
     */
    @Test
    public void testGetVisitDate() {
        System.out.println("getVisitDate");
        WebPage instance = new WebPage("Wake Forest University","http://www.wfu.edu", 
                "1991/04/23", "2024/03/05");
        String expResult = "2024/03/05";
        String result = instance.getVisitDate();
        assertEquals(expResult, result);
    }

    /**
     * Test of getDomain method, of class WebPage.
     */
    @Test
    public void testGetDomain() {
        System.out.println("getDomain");
        WebPage instance = new WebPage("Wake Forest University","http://www.wfu.edu", 
                "1991/04/23", "2024/03/05");
        String expResult = "wfu";
        String result = instance.getDomain();
        assertEquals(expResult, result);
    }

    /**
     * Test of equals method, of class WebPage.
     */
    @Test
    public void testEquals() {
        System.out.println("equals");
        WebPage o = new WebPage("Wake Forest University","http://www.wfu.edu", 
                "1991/04/23", "2024/03/05");
        WebPage instance = new WebPage("Wake Forest University","http://www.wfu.edu", 
                "1991/04/23", "2024/03/05");
        boolean expResult = true;
        boolean result = instance.equals(o);
        assertEquals(expResult, result);
    }

    /**
     * Test of toString method, of class WebPage.
     */
    @Test
    public void testToString() {
        System.out.println("toString");
        WebPage instance = new WebPage("Wake Forest University","http://www.wfu.edu", 
                "1991/04/23", "2024/03/05");
        String expResult = "Wake Forest University<http://www.wfu.edu>";
        String result = instance.toString();
        assertEquals(expResult, result);
    }
    
}
