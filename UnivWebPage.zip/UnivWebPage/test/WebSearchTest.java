
import java.util.ArrayList;
import java.util.function.Predicate;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author darac
 */
public class WebSearchTest {
    /**
     * default constructor  
     */
    public WebSearchTest() {
    }
    

    /**
     * Test of crawlWeb method, of class WebSearch.
     */
    @Test
    public void testCrawlWeb() {
        System.out.println("crawlWeb");
        WebSearch instance = new WebSearch();
        instance.crawlWeb();
    }

    /**
     * Test of filter method, of class WebSearch.
     */
    @Test
    public void testFilter() {
        System.out.println("filter");
        ArrayList<UnivWebPage> pages = new ArrayList<>();
        pages.add(new UnivWebPage("Appalachian State University",
            "http://appstate.edu", "2001/09/17", "2024/03/05"));
        pages.add(new UnivWebPage("Barber-Scotia College",
            "http://b-sc.edu", "1999/03/15", "2024/03/09"));
        Predicate<UnivWebPage> pred=(n) -> n.getYearFounded() > 1960;
        ArrayList<UnivWebPage> filteredList = new WebSearch().filter(pred);
        assertNotNull(filteredList);
    }

    /**
     * Test of foundedAfter method, of class WebSearch.
     */
    @Test
    public void testFoundedAfter() {
        System.out.println("foundedAfter");
        int year = 2002;
        WebSearch instance = new WebSearch();
        ArrayList<UnivWebPage> expResult=new ArrayList<UnivWebPage>();
        expResult.add(new UnivWebPage("Shepherds Theological Seminary",
            "http://www.shepherds.edu", "1993/05/19", "2024/02/01"));
        ArrayList<UnivWebPage> result = instance.foundedAfter(year);
        assertEquals(expResult.get(0),result.get(0));
      
    }

    /**
     * Test of contains method, of class WebSearch.
     */
    @Test
    public void testContains() {
        System.out.println("contains");
        String s = "Shepherds";
        WebSearch instance = new WebSearch();
        ArrayList<UnivWebPage> expResult =new ArrayList<UnivWebPage>();
        expResult.add(new UnivWebPage("Shepherds Theological Seminary",
            "http://www.shepherds.edu", "1993/05/19", "2024/02/01"));
        ArrayList<UnivWebPage> result = instance.contains(s);
        assertEquals(expResult, result);
 
    }

    /**
     * Test of largerThan method, of class WebSearch.
     */
    @Test
    public void testLargerThan() {
        System.out.println("largerThan");
        int size = 36000;
        WebSearch instance = new WebSearch();
        ArrayList<UnivWebPage> expResult = new ArrayList<UnivWebPage>();
        expResult.add(new UnivWebPage("North Carolina State University",
            "http://www.ncsu.edu", "1990/02/12", "2024/03/03"));
        ArrayList<UnivWebPage> result = instance.largerThan(size);
        assertEquals(expResult, result);

    }

    /**
     * Test of univType method, of class WebSearch.
     */
    @Test
    public void testUnivType() {
        System.out.println("univType");
        String t = "public";
        WebSearch instance = new WebSearch();
        ArrayList<UnivWebPage> result = instance.univType(t);
        assertEquals(result, result);
    }

    /**
     * Test of mixedSearch method, of class WebSearch.
     */
    @Test
    public void testMixedSearch() {
        System.out.println("mixedSearch");
        String t = "public";
        int y = 1800;
        int e = 30000;
        WebSearch instance = new WebSearch();
        ArrayList<UnivWebPage> expResult = new ArrayList<UnivWebPage>();
        expResult.add(new UnivWebPage("North Carolina State University",
            "http://www.ncsu.edu", "1990/02/12", "2024/03/03"));
        
        ArrayList<UnivWebPage> result = instance.mixedSearch(t, y, e);
        assertEquals(expResult, result);
    }
    
}
