
/**
 *
 * @author darac
 */
import java.util.ArrayList;
import java.util.function.Predicate;

/**
 * the class for websearch.
 * @author darac
 */
public class WebSearch extends WebSearchADT<UnivWebPage> {
    private ArrayList<UnivWebPage> pages;
    
    @Override
    /**
     * calls crawlweb method.
     */
    public void crawlWeb()
    {
        pages=WebCrawl.crawlWeb();
    }
    
    @Override
    /**
     * filter the list.
     */
    public ArrayList<UnivWebPage> filter(Predicate<UnivWebPage> pred) {
        
        ArrayList<UnivWebPage> filteredList = new ArrayList<>();
        
        if (pages != null && pred != null) {
            for (UnivWebPage page : pages) {
                if (page != null && pred.test(page)) {
                    filteredList.add(page);
                }
            }
        }
        return filteredList;
    }
    @Override
    /**
     * filter it based on the year.
     */
    public ArrayList<UnivWebPage> foundedAfter(int year)
    {
        return filter((n) -> n.getYearFounded() > year);
    }
    @Override
    /**
     * figure out if it has the string.
     */
    public ArrayList<UnivWebPage> contains(String s)
    {
        return filter((n) ->n.getURL().contains(s) || n.getTitle().contains(s));
    }
    @Override
    /**
     * see if the enrollment is larger. 
     */
    public ArrayList<UnivWebPage> largerThan(int size)
    {
        return filter((n) ->n.getEnrollment()>size);
    }
    @Override
    /**
     * return a list of public or private schools.
     */
    public ArrayList<UnivWebPage> univType(String t) 
    {
        return filter((n) -> n.getType().equalsIgnoreCase(t));
    }
    @Override
    /**
     * mixed of all 3 previous methods.
     */
    public ArrayList<UnivWebPage> mixedSearch(String t, int y, int e) {
        
        return filter((n) -> n.getType().equalsIgnoreCase(t) &&n.getYearFounded() > y &&
                n.getEnrollment() > e);
    }
    
    
    
    
    
}
