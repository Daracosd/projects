/**
 *
 * @author darac
 */
public class WebPage {
    private String title;
    private String url;
    private String createDate;
    private String visitDate;
    /**
     * the constructor for a webpage.
     * @param title the string title 
     * @param url the string title 
     * @param createDate the string create date 
     * @param visitDate  the string visit date
     */
    public WebPage(String title, String url, String createDate, String visitDate) 
    {
        this.title = title;
        this.url = url;
        this.createDate = createDate;
        this.visitDate = visitDate;
    }
     
    /**
     * return the title of the webpage.
     * @return a string
     */
    public String getTitle()
    {
        return title;
   
    }
    /**
     * return the url.
     * @return a string 
     */
    public String getURL()
    {
        return url;
    }
    /**
     * return the create date.
     * @return a string 
     */
    public String getCreateDate()
    {
        return createDate;
    }
    /**
     * return the visit date.
     * @return a string 
     */
    public String getVisitDate()
    {
        return visitDate;
    }
    /**
     * return the domain of the url. 
     * @return a string 
     */
    public String getDomain()
    {
        String domainURl=this.getURL();
        String[] domain=domainURl.split("//");
        String[] domain2=domain[1].split("[.]");
        return domain2[1];
    }
    /**
     * see if the webpage is equal to this.
     * @param obj a webpage or string 
     * @return true or false
     */
    public boolean equals(Object obj)
    {
     
        if (obj== null) {
            return false;
        }
      
        if (!(obj instanceof WebPage) && !(obj instanceof String)) {
            return false;
        }
        
        if (obj instanceof String) {
            String otherUrl = (String) obj;
            return this.url.equalsIgnoreCase(otherUrl);
        }
        
        WebPage otherPage = (WebPage) obj;
        return this.url.equalsIgnoreCase(otherPage.getURL());
    }
    /**
     * return the variable into a string.
     * @return a string 
     */
    public String toString()
    {
        return this.getTitle()+"<"+this.getURL()+">";
    }

}
