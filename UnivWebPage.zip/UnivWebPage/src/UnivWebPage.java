


/**
 *
 * @author darac
 */
public class UnivWebPage extends WebPage {
    private int enrollment;
    private int yearFounded;
    private String type="";
    /**
     * the constructor. 
     * @param title of the uni
     * @param url of the uni
     * @param createDate of the uni
     * @param visitDate  of the uni
     */
    public UnivWebPage(String title, String url, String createDate, String visitDate)
    {
        super(title,url,createDate,visitDate);
        this.enrollment=enrollment;
        this.yearFounded=yearFounded;
        this.type=type;
    }
    /**
     * returns the size.
     * @return int of uni size
     */
    public int getEnrollment() {
        return enrollment;
    }

    /**
     * set the type of the uni.
     * @param type public or private 
     */
    public void setType(String type) {
        this.type = type;
    }
    /**
     * return the type of uni.
     * @return private or public
     */
    public String getType() {
        return type;
    }

    /**
     * set the enrollment size.
     * @param enrollment size of the uni
     */
    public void setEnrollment(int enrollment) {
        this.enrollment = enrollment;
    }


    /**
     * return the year founded of the uni.
     * @return the year as an int
     */
    public int getYearFounded() {
        return yearFounded;
    }

    /**
     * set the year founded for the uni.
     * @param yearFounded an int value to be set with the uni
     */
    public void setYearFounded(int yearFounded) {
        this.yearFounded = yearFounded;
    }

   
    
}
