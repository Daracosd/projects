public class Wood extends Resource{
    private String name;
    private int quantity;
    private boolean isCritical;
    public Wood(String name,int quantity,boolean isCritical) {
        super(name);
        this.name=name;
        this.quantity=quantity;
        this.isCritical=false;
    }
    public int getQuantity() {
        return quantity;
    }
    public String toString(){
        return name+" "+quantity;
    }
    public void add(int amount) {
        quantity += amount;
    }
    public void consume(int amount) {
        if (quantity >= amount) {
            quantity -= amount;
        } else {
            quantity = 0;
            System.out.println("Not enough " + name + " to consume.");
        }
    }

}