import java.util.ArrayList;

public class Wood extends Resource {

    public Wood() {
        super("Wood"); 
    }

    public Wood(int quantity) {
        super("Wood", quantity); 
    }

    @Override
    public void perTurnConsumption(ArrayList<Generator> g){
        //No wood is consumed per turn        
    }
}