import java.util.ArrayList;

public class Gold extends Resource {
    
    int perTurnConsumption = 0;

    public Gold() {
        super("Gold"); 
        super.setIsCritical(true);
    }

    public Gold(int quantity) {
        super("Gold", quantity); 
        super.setIsCritical(true);
    }

    //Gold does raise the score
    @Override
    public int scoreImpact(){
        return super.getQuantity();
    }

    public void setPerTurnConsumption(int value){
        perTurnConsumption = value;
    }

    public int getPerTurnConsumption(){
        return perTurnConsumption;
    }

    @Override
    public void perTurnConsumption(ArrayList<Generator> g){
        super.consume(perTurnConsumption);
    }

}