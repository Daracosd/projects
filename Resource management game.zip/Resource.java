import java.util.ArrayList;

/**
 * The Resource class represents a generic resource in the game.
 * Resources have a name, a quantity, and a status of critical or not critical.
 */
public abstract class Resource implements Score, Comparable<Resource>{
    private String name;
    private int quantity;
    private boolean isCritical;

    /**
     * Creates a new Resource with the given name and initializes the quantity to 0.
     *
     * @param name the name of the resource
     */
    public Resource(String name) {
        this.name = name;
        this.quantity = 0;
        this.isCritical = false;
    }

    /**
     * Creates a new Resource with the given name and initializes the quantity to the passed in value.
     *
     * @param name the name of the resource
     * @param quantity the quantity of the resource
     */
    public Resource(String name, int quantity) {
        this.name = name;
        this.quantity = quantity;
        this.isCritical = false;
    }

    /**
     * Gets the name of the resource.
     *
     * @return the name of the resource
     */
    public String getName() {
        return name;
    }

    /**
     * Gets the quantity of the resource.
     *
     * @return the quantity of the resource
     */
    public int getQuantity() {
        return quantity;
    }

    /**
     * Reports if a resource is critical. If a rsource is critical, reaching 0 ends the game.
     *
     * @return if the resource is critical
     */
    public boolean isCritical(){
        return isCritical;
    }

    /**
     * Sets if a given resource is critical.
     * 
     * @param boolean value for isCritical
     */
    public void setIsCritical(boolean isCritical){
        this.isCritical = isCritical;
    }

    /**
     * Adds the specified amount to the quantity of the resource.
     *
     * @param amount the amount to add
     */
    public void add(int amount) {
        quantity += amount;
    }

    /**
     * Consumes the specified amount of the resource if available. Sets the resource to 0 if there is not enough to consume.
     *
     * @param amount the amount to consume
     */
    public void consume(int amount) {
        if (quantity >= amount) {
            quantity -= amount;
        } else {
            quantity = 0;
            System.out.println("You are out of " + name + "!");
        }
    }

    public String toString(){
        return getName() + " : " + getQuantity();
    }
    
    //Resources do not have an impact on the score
    public int scoreImpact(){
        return 0;
    }

    public int compareTo(Resource other){
        if(quantity > other.getQuantity()){
            return 1;
        } else if (quantity < other.getQuantity()){
            return -1;
        } else {
            return 0;
        }
    }

    public abstract void perTurnConsumption(ArrayList<Generator> g);
    
}