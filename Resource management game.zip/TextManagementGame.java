import java.util.Scanner;
import java.util.ArrayList;
import java.util.*;
import java.util.Random;

/**
 * The TextManagementGame class represents a text-based management game where the player manages resources and resource generators.
 */
public class TextManagementGame  {
    // Define game variables
    private int round;
    private int score;
    private ArrayList<Resource> resources = new ArrayList<Resource>();
    private ArrayList<Generator> generators = new ArrayList<Generator>();

    // Define a Scanner for user input
    private Scanner scanner;

    /**
     * Creates a new TextManagementGame instance with initial resource and time values.
     * TODO : Add starting resources
     */
    public TextManagementGame() {
        round = 1;       // Start at time 1
        score=0; //score at zero
        scanner = new Scanner(System.in);
        
        
        
    }

    /**
     * Check if a method should run with a 1 in number chance.
     *
     * @return true if the method should run, false otherwise
     */
    public boolean haveEventThisTurn(int number) {
        Random random = new Random();
        int chance = random.nextInt(number); // Generates a random number between 0 (inclusive) and number (exclusive)
        return chance == 0; // Returns true with a 1 in number chance
    }
    //returns the score value
    public int getScore(){
        return score;
    }

    /**
    * Prints the list of resources
    */
    public void viewResources(){
        for(Resource r : resources){
            System.out.println(r);
        }
    }

    /**
    * Prints the list of Generators
    */
    public void viewGenerators(){
        for(Generator b : generators){
            b.printResources();
        }
    }

    /**
     * Checks if a Generator can be constructed and then adds it to the list of Generators
     * TODO : ADD LOGIC
     */
    public void constructGenerator(){
        boolean woodCheck=false;
        boolean stoneCheck=false;
        boolean foodCheck=false;
        int tempWood=0;
        int tempStone=0;
        int tempFood=0;
        //determines what can be built base on the amounts of resources
        for(Generator g: generators){
            for(Resource r: g.getConstructionCost()){
                for (Resource t: resources) {
                    if (r instanceof Wood && t instanceof Wood) {
                        if (r.getQuantity()<t.getQuantity()) {
                            woodCheck=true;
                            tempWood=r.getQuantity();

                        }
                    }
                    if (r instanceof Food && t instanceof Food) {
                        if (r.getQuantity()<t.getQuantity()) {
                            foodCheck=true;
                            tempFood=r.getQuantity();

                        }
                    }
                    
                    if (r instanceof Stone && t instanceof Stone) {
                        if (r.getQuantity()<t.getQuantity()) {
                            stoneCheck=true;
                            tempStone=r.getQuantity();
                        }
                    }
                    
                    if (woodCheck!=false&&stoneCheck!=false&&foodCheck!=false) {
                        g.setNumberConstructed(1);
                        System.out.print(g.getNumberConstructed());
                        woodCheck=false;
                        stoneCheck=false;
                        foodCheck=false;
                        for(Resource n: resources){
                            if (n instanceof Wood) {
                            n.consume(tempWood);
                            }
                            if (n instanceof Stone) {
                            n.consume(tempStone);
                            }
                            if (n instanceof Food) {
                            n.consume(tempFood);
                            }
                        }
                        
                    }
                    if (woodCheck!=false&&stoneCheck!=false) {
                        g.setNumberConstructed(1);
                        woodCheck=false;
                        stoneCheck=false;
                        for(Resource n: resources){
                            if (n instanceof Wood) {
                            n.consume(tempWood);
                            }
                            if (n instanceof Stone) {
                            n.consume(tempStone);
                            }
                        }
                        
                    }
                    
                }

            }
        }        
        for(Generator b : generators){
            b.printResources();
        }   
    }

    /** 
     * Increments the time counter and then adds more resources based on what generators are present
     * TODO : Add calculations to generate resources for the next turn
     */
    public void endRound(){
        round++;
        //ends the round while calculating the amount of resources should be added 
        for(Generator a: generators){
            for (Resource b: resources) {
                if (a.getProduct() instanceof Wood && b instanceof Wood) {
                    b.add(a.getResourceProductionRate()*a.getNumberConstructed());
                    b.add(10);
                }
                if (a.getProduct() instanceof Stone && b instanceof Stone) {
                    b.add(a.getResourceProductionRate()*a.getNumberConstructed());
                    b.add(10);
                }
                if (a.getProduct() instanceof Food && b instanceof Food) {
                    b.add(a.getResourceProductionRate()*a.getNumberConstructed());
                    b.add(10);
                }
            }
            
        }

    }

    /**
     * Adds a Generator object to the ArrayList of Generators.
     *
     * @param Generator the Generator object to add
     */
    public void addGenerator(Generator generator) {
        generators.add(generator);
    }

    /**
     * Adds a Resource object to the ArrayList of resources.
     *
     * @param resource the Resource object to add
     */
    public void addResource(Resource resource) {
        resources.add(resource);
    }
    //addes the para score amount into the field score
    public void addScore(int score) {
        this.score=this.score+score;
    }

    /**
     * Checks if we are out of any critical resources
     *
     * @return returns true if we are out of any critical resources returns false otherwise
    */
    public boolean isCriticalResourceEmpty(){
        for(Resource r : resources){
            if(r.isCritical() && r.getQuantity() == 0){
                return true;
            }
        }
        return false;
    }
    //sorts the arraylist with the compareTo method from the resource class
    public void sortResource(){
        Collections.sort(resources);
    }
    

    /**
     * Starts the game and manages the game loop.
     */
    public void start() {
        System.out.println("50 day"); //TODO: Change Text
        
        int oddsOfRandomEvent = 6; //a 25% chance of a random event occuring

        // Main game loop
        while (round<50) {
            System.out.println("\nDay " + round);
            if(haveEventThisTurn(oddsOfRandomEvent)){
                //TODO add logic for random events
                Random random = new Random();
                int chance = random.nextInt(3);
                System.out.println("A random event happened!");
                Event fire= new Event("Fire");
                Event flood= new Event("Flood");
                Event bugs= new Event("Bugs");
                TextManagementGame scoreAdding=new TextManagementGame();


                // the random events 
                if (chance==0) {
                    System.out.println(fire.getName()+": lose half of your wood");
                    scoreAdding.addScore(fire.scoreImpact());
                    for (Resource r:resources) {
                        if (r instanceof Wood) {
                            r.consume((int)(r.getQuantity()*0.5));
                        }
                    }
                }
                if (chance==1) {
                    System.out.println(flood.getName()+": lose half of your resources");
                    scoreAdding.addScore(flood.scoreImpact());
                    for (Resource r:resources) {
                        r.consume((int)(r.getQuantity()*0.5));
                        
                    }   
                }
                if (chance==2) {
                    System.out.println(bugs.getName()+": lose half of your food");
                    scoreAdding.addScore(bugs.scoreImpact());
                    for (Resource r:resources) {
                        if (r instanceof Food) {
                            r.consume((int)(r.getQuantity()*0.5));
                        }
                        
                    }   
                }

                    

            }
            System.out.println("Options:");
            System.out.println("1. View resources");
            System.out.println("2. View generators");
            System.out.println("3. Add a new Generator");
            System.out.println("4. End round");
            System.out.println("5. Score");
            System.out.println("6. Quit game");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    viewResources();
                    break;
                case 2:
                    viewGenerators();
                    break;
                case 3: 
                    constructGenerator();
                    break;
                case 4:
                    endRound();
                    break;
                case 5:
                //tells the score of the player based on their generator and resource amount
                TextManagementGame scoreAdding=new TextManagementGame();
                scoreAdding.sortResource();
                    for(Generator g:generators){
                        scoreAdding.addScore(g.scoreImpact());
                    }
                    for(Resource r:resources){
                        scoreAdding.addScore(r.scoreImpact());
                    }
                    System.out.println("Your overall score: "+scoreAdding.getScore());
                    for (Resource r:resources) {
                        System.out.println(r);
                    }
                    for (Generator g:generators) {
                        System.out.println(g);
                    }
                    break;
                case 6:
                scoreAdding=new TextManagementGame();
                scoreAdding.sortResource();
                    for(Generator g:generators){
                        scoreAdding.addScore(g.scoreImpact());
                    }
                    for(Resource r:resources){
                        scoreAdding.addScore(r.scoreImpact());
                    }
                    System.out.println("Your overall score: "+scoreAdding.getScore());
                    for (Resource r:resources) {
                        System.out.println(r);
                    }
                    for (Generator g:generators) {
                        System.out.println(g);
                    }


                    System.exit(0);
                    


                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }

        System.out.println("Game Over! You ran out of resources.");
        System.out.println("You played for " + round + " rounds");
    }

    /**
     * Main method to run the game
     *
     * @param args the command-line arguments (not used in this game)
     */
    public static void main(String[] args) {
        TextManagementGame game = new TextManagementGame();
        Wood woodLubmer= new Wood("Wood",10,false);
        Stone stoneLubmer= new Stone("Stone",15,false);
        ArrayList<Resource> lubmerMillCost= new ArrayList<Resource>();
        LumberMill lumberMill=new LumberMill("Lumber Mill",lubmerMillCost,20,0,woodLubmer);
        lubmerMillCost.add(woodLubmer);
        lubmerMillCost.add(stoneLubmer);
        
        Wood woodFarm= new Wood("Wood",30,false);
        Stone stoneFarm= new Stone("Stone",35,false);
        Food foodFarm= new Food("Stone",10,false);
        ArrayList<Resource> farmCost= new ArrayList<Resource>();
        Farm farm=new Farm("Farm",farmCost,20,0,foodFarm);
        farmCost.add(woodFarm);
        farmCost.add(stoneFarm);
        farmCost.add(foodFarm);
        


        Wood woodMine= new Wood("Wood",30,false);
        Stone stoneMine= new Stone("Stone",25,false);
        ArrayList<Resource> mineCost= new ArrayList<Resource>();
        Mine mine=new Mine("Mine",mineCost,20,0,stoneMine);
        mineCost.add(woodMine);
        mineCost.add(stoneMine);
        game.addGenerator(farm);
        game.addGenerator(mine);
        game.addGenerator(lumberMill);
        Food food=new Food("Food",50,true);
        Wood wood=new Wood("Wood",50,false);
        Stone stone=new Stone("Stone",50,false);
        game.addResource(food);
        game.addResource(wood);
        game.addResource(stone);
        game.start();
    }
}