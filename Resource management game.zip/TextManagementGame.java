import java.util.Scanner;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

/**
 * The TextManagementGame class represents a text-based management game where the player manages resources and resource generators.
 */
public class TextManagementGame {
    // Define game variables
    private int round;
    private ArrayList<Resource> resources = new ArrayList<Resource>();
    private ArrayList<Generator> generators = new ArrayList<Generator>();
    private ArrayList<Event> events = new ArrayList<Event>();
    private int eventScore;

    // Define a Scanner for user input
    private Scanner scanner;

    /**
     * Creates a new TextManagementGame instance with initial resource and time values.
     */
    public TextManagementGame() {
        round = 1;       // Start at time 1
        scanner = new Scanner(System.in);
        //Create the starting resources
        //Start with 200 food, 100 gold and 50 wood
        Food f = new Food();
        f.add(200);
        Gold g = new Gold();
        g.add(100);
        Stone s = new Stone();
        Wood w = new Wood();
        w.add(50);
        resources.add(f);
        resources.add(g);
        resources.add(s);
        resources.add(w);
        //Create the generators. 
        //Do not start with any generators
        ArrayList<Resource> costOfCastle = new ArrayList<Resource>();
        costOfCastle.add(new Stone(100));
        costOfCastle.add(new Wood(25));
        ArrayList<Resource> costOfFarm = new ArrayList<Resource>();
        costOfFarm.add(new Wood(2));
        costOfFarm.add(new Gold(2));
        ArrayList<Resource> costOfLumberMill = new ArrayList<Resource>();
        costOfLumberMill.add(new Wood(10));
        costOfLumberMill.add(new Gold(2));
        ArrayList<Resource> costOfMine = new ArrayList<Resource>();
        costOfMine.add(new Wood(50));
        costOfMine.add(new Gold(20));
        generators.add(new Castle(costOfCastle, g));
        generators.add(new Farm(costOfFarm, f));
        generators.add(new LumberMill(costOfLumberMill, w));
        generators.add(new Mine(costOfMine, s));
        //Create the events
        for(Resource r : resources){
            events.add(new Event("Lose " + r.getName(), r, 10));
        }
        for(Resource r : resources){
            events.add(new Event("Lose " + r.getName(), r, 20));
        }
        for(Resource r : resources){
            events.add(new Event("Lose " + r.getName(), r, 50));
        }
        for(Resource r : resources){
            events.add(new Event("Lose " + r.getName(), r, 100));
        }
        for(Resource r : resources){
            events.add(new Event("Lose " + r.getName(), r, 200));
        }
    }

    /**
     * Check if a method should run with a 1 in number chance.
     *
     * @return true if the method should run, false otherwise
     */
    public boolean haveEventThisTurn(int number) {
        Random random = new Random();
        int chance = random.nextInt(number); // Generates a random number between 0 (inclusive) and number (exclusive)
        return chance == 0; // Returns true with a 1 in number chance
    }

    /**
    * Prints the list of resources
    */
    public void viewResources(){
        Collections.sort(resources);
        for(Resource r : resources){
            System.out.println(r);
        }
    }

    /**
    * Prints the list of Generators
    */
    public void viewGenerators(){
        Collections.sort(generators);
        for(Generator b : generators){
            System.out.println(b);
        }
    }

    /**
     * Checks if a Generator can be constructed and then adds it to the list of Generators
     */
    public void constructGenerator(){
        System.out.println("Which type of building would you like to construct?");
        for(int i = 0; i<generators.size(); i++){
            System.out.println(i+1 + ". " + generators.get(i).getName());
        }
        int choice = scanner.nextInt();
        generators.get(choice - 1).buildGenerator(resources);
    }

    /** 
     * Increments the time counter and then adds more resources based on what generators are present
     */
    public void endRound(int oddsOfRandomEvent){
        round++;
        for(Generator g : generators){
            g.makeResources();
        }

        for(Resource r : resources){
            r.perTurnConsumption(generators);
        }

        if(haveEventThisTurn(oddsOfRandomEvent)){
            Random random = new Random();
            int chosenEvent = random.nextInt(events.size()); // Generates a random number between 0 (inclusive) and events.size() (exclusive)
            events.get(chosenEvent).eventOccurs();
            eventScore += events.get(chosenEvent).scoreImpact();
        }
    }

    /**
     * Adds a Generator object to the ArrayList of Generators.
     *
     * @param Generator the Generator object to add
     */
    public void addGenerator(Generator generator) {
        generators.add(generator);
    }

    /**
     * Adds a Resource object to the ArrayList of resources.
     *
     * @param resource the Resource object to add
     */
    public void addResource(Resource resource) {
        resources.add(resource);
    }

    /**
     * Checks if we are out of any critical resources
     *
     * @return returns true if we are out of any critical resources returns false otherwise
    */
    public boolean isCriticalResourceEmpty(){
        for(Resource r : resources){
            if(r.isCritical() && r.getQuantity() <= 0){
                return true;
            }
        }
        return false;
    }

    public int calculateScore(){
        int totalScore = 0;
        //Score from resources
        for(Resource r : resources){
            totalScore += r.scoreImpact();
        }
        //Score from generators
        for(Generator g : generators){
            totalScore += g.scoreImpact();
        }
        //Score from events
        totalScore += eventScore;
        return totalScore;
    }

    /**
     * Prints instructions
     */
    public void howToPlay(){
        System.out.println("Build the best city possible. If you run out of food or gold, the game will end.");
        System.out.println("Each turn, choose what to build. You use two food each turn for every building in the game.\n");
        for(Generator g : generators){
            System.out.println(g.getDetails());
        }
        
        for(Generator g : generators){
            System.out.println("\nBuilding a " + g.getName() + " costs: ");
            g.printConstructionCost();
        }
    }

    /**
     * Starts the game and manages the game loop.
     */
    public void start() {
        System.out.println("Welcome to the City Builder Game!"); 
        int oddsOfRandomEvent = 4; //a 25% chance of a random event occuring
        int totalScore = 0;

        // Main game loop
        while (!isCriticalResourceEmpty()) {
            System.out.println("\nTime " + round);
            System.out.println("Options:");
            System.out.println("1. View resources");
            System.out.println("2. View buildings");
            System.out.println("3. Add a new building");
            System.out.println("4. End round");
            System.out.println("5. How to Play.");
            System.out.println("6. Get current score.");
            System.out.println("7. Quit game");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    viewResources();
                    break;
                case 2:
                    viewGenerators();
                    break;
                case 3: 
                    constructGenerator();
                    break;
                case 4:
                    endRound(oddsOfRandomEvent);
                    break;
                case 5:
                    howToPlay();
                    break;
                case 6: 
                    System.out.println("Your score is " + calculateScore());
                    break;
                case 7:
                    System.out.println("Thank you for playing! Your score is " + calculateScore());
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
                    break;
            }
        }

        System.out.println("Game Over! You ran out of resources.");
        System.out.println("You played for " + round + " rounds");
        System.out.println("Thank you for playing! Your score is " + calculateScore());
    }

    /**
     * Main method to run the game
     *
     * @param args the command-line arguments (not used in this game)
     */
    public static void main(String[] args) {
        TextManagementGame game = new TextManagementGame();
        game.start();
    }
}