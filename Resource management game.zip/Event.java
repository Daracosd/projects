/**
 * The Event class represents a generic randomly occuring event in the game.
 * Events have a name
 */
public class Event implements Score{
    private String name;
    private Resource resource;
    private int impact;

    /**
     * Creates a new Event with the given name
     *
     * @param name the name of the event
     */
    public Event(String name, Resource resource, int impact) {
        this.name = name;
        this.resource = resource;     
        this.impact = impact;
    }

    /**
     * Gets the name of the event.
     *
     * @return the name of the event
     */
    public String getName() {
        return name;
    }

    public void eventOccurs(){
        if(resource.getQuantity() > 0){
            if(resource.getQuantity() < impact){
                System.out.println("A crisis! " + resource.getQuantity() + " of your " + resource.getName() + " has been lost!");    
            } else {
                System.out.println("A crisis! " + impact + " of your " + resource.getName() + " has been lost!");
            }
            resource.consume(impact);
        }
    }

    public int scoreImpact(){
        return impact;
    }

}