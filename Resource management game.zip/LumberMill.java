import java.util.ArrayList;

public class LumberMill extends Generator {
 
    public LumberMill(ArrayList<Resource> constructionCost, Resource product) {
        super("Lumber Mill", constructionCost, 5, 0, product);
    }
    
}