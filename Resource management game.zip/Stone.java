import java.util.ArrayList;

public class Stone extends Resource {
    
    public Stone() {
        super("Stone"); 
    }

    public Stone(int quantity) {
        super("Stone", quantity); 
    }

    @Override
    public void perTurnConsumption(ArrayList<Generator> g){
        //No stone is consumed per turn   
    }

}