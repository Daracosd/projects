import java.util.ArrayList;

public class Food extends Resource {

    public Food() {
        super("Food"); 
        super.setIsCritical(true);
    }

    public Food(int quantity){
        super("Food", quantity); 
        super.setIsCritical(true);
    }

    @Override
    public void perTurnConsumption(ArrayList<Generator> generators){
        int numberOfBuildings = 0;
        for(Generator g : generators){
            numberOfBuildings += g.getNumberConstructed();
        }
        consume(numberOfBuildings * 2);
    }
}