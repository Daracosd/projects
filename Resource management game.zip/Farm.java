import java.util.ArrayList;

public class Farm extends Generator {
    
    public Farm(ArrayList<Resource> constructionCost, Resource product) {
        super("Farm", constructionCost, 5, 0, product);
    }


}