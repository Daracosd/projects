import java.util.*;
public class Farm extends Generator {
    private String name;
    private ArrayList<Resource> constructionCost;
    private int resourceProductionRate;
    private int numberConstructed;
    private Resource product;

    public Farm(String name, ArrayList<Resource> constructionCost, int resourceProductionRate, int numberConstructed, Resource product) {
        super(name,constructionCost,resourceProductionRate,numberConstructed,product );
        this.name = name;
        this.constructionCost = constructionCost;
        this.resourceProductionRate = resourceProductionRate;
        this.numberConstructed = numberConstructed;
        this.product = product;
    }
    public String getName() {
        return name;
    }
    public ArrayList<Resource> getConstructionCost() {
        return constructionCost;
    }
    public int getResourceProductionRate() {
        return resourceProductionRate;
    }
    public int getNumberConstructed() {
        return numberConstructed;
    }
    public void setNumberConstructed(int s) {
        numberConstructed=numberConstructed+s;
    }
    public Resource getProduct() {
        return product;
    }

    
    @Override
    public void printResources(){
        System.out.println(this.name);
        for(Resource r:this.getConstructionCost()){
            System.out.println(r.getName() +": "+r.getQuantity());
        }
        System.out.println("\nProduction Rate: "+this.resourceProductionRate);
        System.out.println("Number Made: "+this.numberConstructed);
    }
    public String toString(){
        return "Name: "+this.name+" Number: "+this.numberConstructed;
    }
}