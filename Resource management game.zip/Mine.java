import java.util.ArrayList;

public class Mine extends Generator {
    
    public Mine(ArrayList<Resource> constructionCost, Resource product) {
        super("Mine", constructionCost, 5, 0, product);
    }

}