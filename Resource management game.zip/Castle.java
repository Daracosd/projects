import java.util.ArrayList;

public class Castle extends Generator {
    
    public Castle(ArrayList<Resource> constructionCost, Resource product) {
        super("Castle", constructionCost, 5, 0, product);
    }

    //Castles give 1000 points per castle
    @Override
    public int scoreImpact(){
        return super.getNumberConstructed() * 1000;
    }

}