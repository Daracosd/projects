import java.util.ArrayList;

/**
 * The Generator class represents a generic resource generating item in the game.
 * Generators have a name, a construction cost, and a resource production rate.
 */
public abstract class Generator implements Score, Comparable<Generator>{
    private String name;
    private ArrayList<Resource> constructionCost;
    private int resourceProductionRate;
    private int numberConstructed;
    private Resource product;

    /**
     * Creates a new Generator with the given name, construction cost, and resource production rate.
     *
     * @param name                  the name of the Generator
     * @param constructionCost      the cost in resources required to construct the Generator
     * @param resourceProductionRate the rate at which the Generator produces resources per unit of time
     * @param numberConstructed     the number of units of this generator constructed at this time
     * @param product               the type of resource this generator produces
     */
    public Generator(String name, ArrayList<Resource> constructionCost, int resourceProductionRate, int numberConstructed, Resource product) {
        this.name = name;
        this.constructionCost = constructionCost;
        this.resourceProductionRate = resourceProductionRate;
        this.numberConstructed = numberConstructed;
        this.product = product;
    }

    /**
     * Gets the name of the Generator.
     *
     * @return the name of the Generator
     */
    public String getName() {
        return name;
    }

    /**
     * Gets the construction cost of the Generator.
     *
     * @return the construction cost of the Generator
     */
    public ArrayList<Resource> getConstructionCost() {
        return constructionCost;
    }

    /**
     * Gets the resource production rate of the Generator.
     *
     * @return the resource production rate of the Generator
     */
    public int getResourceProductionRate() {
        return resourceProductionRate;
    }

    /**
     * Gets the number of units constructed of this Generator.
     *
     * @return the number of units constructed of the generator
     */
    public int getNumberConstructed() {
        return numberConstructed;
    }


    /**
     * Gets the product of this Generator.
     *
     * @return the product
     */
    public Resource getProduct(){
        return product;
    }

    /**
     * Makes the resources that the generator produces based on the rate of production and the number of generators
     */
    public void makeResources(){
        getProduct().add(getNumberConstructed() * getResourceProductionRate());
    }

    /**
     * Builds a new generator
     */
    public void buildGenerator(ArrayList<Resource> resourceStock){
        //Checks if there are enough of a resource needed to build
        boolean enoughResourcesToBuild = true;

        //First, check if there are enough resources to build
        //Iterates through the list of costs
        for(Resource c : constructionCost){
            //Checks the stock for the costs
            for(Resource r : resourceStock){
                //If the cost and the resource from the stock are the same type
                if(c.getClass() == r.getClass()){
                    if(c.getQuantity() > r.getQuantity()){
                        //If there are fewer resources in the stock than in the cost set enoughResources to false
                        enoughResourcesToBuild = false;
                    }
                }
            }
        }

        //If there are enough resources, then build
        if(enoughResourcesToBuild){
            for(Resource c : constructionCost){
                for(Resource r : resourceStock){
                    if(c.getClass() == r.getClass()){
                        //Deduct resources from the correct classes
                        r.consume(c.getQuantity());
                    }
                }
            }
            //Once used all the cost, increment number constructed
            numberConstructed++;
        } else {
            System.out.println("Not enough resources to build " + getName());
        }

    }

    public String toString(){
        return name + " : " + numberConstructed;
    }

    public String getDetails(){
        return "[" + name + "] - "  + numberConstructed + " built. Each produces " + getResourceProductionRate() + " " + product.getName() + " per round.";
    }

    public void printConstructionCost(){
        for(Resource r : constructionCost){
            System.out.println("\t" + r.getName() + " : " + r.getQuantity());
        }
    }

    //Generators earn 100 points per building
    public int scoreImpact(){
        return numberConstructed * 100;
    }

    public int compareTo(Generator other){
        if(numberConstructed > other.getNumberConstructed()){
            return 1;
        } else if (numberConstructed < other.getNumberConstructed()){
            return -1;
        } else {
            return 0;
        }
    }
}