public interface Score {
    int scoreImpact();

    

}