public interface Score {

    public int scoreImpact();
    
}
